CREATE TABLE IF NOT EXISTS items (
    name VARCHAR(100),
    price INT
);
INSERT INTO items VALUES ('Apple', 2);
INSERT INTO items VALUES ('Orange', 3);
INSERT INTO items VALUES ('Cherry', 1);
