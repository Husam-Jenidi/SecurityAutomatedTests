CREATE DATABASE IF NOT EXISTS fstt23_assignment;
USE fstt23_assignment;
