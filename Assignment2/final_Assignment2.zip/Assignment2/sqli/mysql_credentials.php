<?php

$mysql_server = "localhost";
$mysql_user = "root";
$mysql_pass = "husam";
$mysql_db = "fstt23_assignment"; 

